
Запуск бд
выполнить в корне docker-compose up